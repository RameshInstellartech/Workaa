//
//  NotificTableViewCell.swift
//  Workaa
//
//  Created by IN1947 on 10/07/17.
//  Copyright © 2017 IN1947. All rights reserved.
//

import UIKit

class NotificTableViewCell: UITableViewCell
{
    @IBOutlet weak var msglbl = KILabel()
    @IBOutlet weak var logimage = AsyncImageView()
    @IBOutlet weak var msgheight = NSLayoutConstraint()
    @IBOutlet weak var imgwidth = NSLayoutConstraint()

    override func awakeFromNib()
    {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool)
    {
        super.setSelected(selected, animated: animated)
        // Configure the view for the selected state
    }
}
