//
//  NotificationViewController.swift
//  Workaa
//
//  Created by IN1947 on 10/07/17.
//  Copyright © 2017 IN1947. All rights reserved.
//

import UIKit

class NotificationViewController: UIViewController, UITableViewDelegate, UITableViewDataSource, ConnectionProtocol
{
    @IBOutlet weak var tblNotificList: UITableView!

    var connectionClass = ConnectionClass()
    var commonmethodClass = CommonMethodClass()
    var notificArray = NSArray()

    override func viewDidLoad()
    {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        connectionClass.delegate = self
        
        tblNotificList.register(UINib(nibName: "NotificTableViewCell", bundle: nil), forCellReuseIdentifier: "NotificCellID")
        
        self.getNotificMsg()
    }
    
    override func viewWillAppear(_ animated: Bool)
    {
        super.viewWillAppear(animated)
        
        self.navigationController?.navigationBar.isHidden = false
        
        navigationController?.navigationBar.barTintColor = blueColor
        
        self.title = "Notification"
    }
    
    func getNotificMsg()
    {
        appDelegate.loadanimatingView(frame: CGRect(x: 0.0, y: 0.0, width: screenWidth, height: screenHeight-64.0), view: self.view)
        
        commonmethodClass.delayWithSeconds(0.0, completion: {
            self.connectionClass.getNotificList()
        })
    }
    
    func readNotificMsg()
    {
        self.connectionClass.readNotific()
    }
    
    func GetFailureReponseMethod(errorreponse: String)
    {
        print("GetFailureReponseMethod")
        appDelegate.stopanimatingView()
    }
    
    func GetReponseMethod(reponse : NSDictionary)
    {
        print("reponse => \(reponse)")
        
        if let getreponse = reponse.value(forKey: "data") as? NSDictionary
        {
            if let getnotificlist = getreponse.value(forKey: "records") as? NSArray
            {
                notificArray = getnotificlist
                tblNotificList.reloadData()
            }
            
            self.readNotificMsg()
        }
        else
        {
            notificunreadcount = 0
        }
        
        print("notificArray =>\(notificArray.count)")
        
        appDelegate.stopanimatingView()
    }
    
    func getmsg(process : String, firstName : String, groupName : String, teamName : String) -> String
    {
        var message = String()
        switch process
        {
            case "taskAdd":
                message = String(format: "%@ added a new task  for you in %@", firstName, groupName)
                break
            case "myTaskAdd":
                message = String(format: "You have added a task for yourself in %@", groupName)
                break
            case "queueAdd":
                message = String(format: "%@ has added a new task to Queue in %@", firstName, groupName)
                break
            case "queueEdit":
                message = String(format: "%@ has edited a task in Queue in %@", firstName, groupName)
                break
            case "queueRemove":
                message = String(format: "%@ has removed a task in Queue in %@", firstName, groupName)
                break
            case "queueReject":
                message = String(format: "%@ has rejected your task in Queue in %@", firstName, groupName)
                break
            case "taskOneDone":
                message = String(format: "%@ has completed a task in %@", firstName, groupName)
                break
            case "taskAllDone":
                message = String(format: "%@ and others completed a task in %@", firstName, groupName)
                break
            case "taskOwnDone":
                message = String(format: "%@ has completed a self-assigned task in %@", firstName, groupName)
                break
            case "teamMarkAdmin":
                message = String(format: "%@ added you as Admin for %@", firstName, teamName)
                break
            case "teamRemoveAdmin":
                message = String(format: "%@ removed you as Admin from %@", firstName, teamName)
                break
            case "groupCreate":
                message = String(format: "%@ created a new group '%@'", firstName, groupName)
                break
            case "groupInvite":
                message = String(format: "%@ added you to '%@'", firstName, groupName)
                break
            case "groupUserRemove":
                message = String(format: "%@ removed you from '%@'", firstName, groupName)
                break
            case "groupMarkAdmin":
                message = String(format: "%@ added you as Admin for '%@'", firstName, groupName)
                break
            case "groupRemoveAdmin":
                message = String(format: "%@ removed you as Admin from '%@'", firstName, groupName)
                break
            case "teamUserAdd":
                message = String(format: "%@ added you to '%@'", firstName, teamName)
                break
            case "teamUserRemove":
                message = String(format: "%@ removed you from '%@'", firstName, teamName)
                break
            case "teamInvite":
                message = String(format: "%@ added you to '%@'", firstName, teamName)
                break
            default:
                break
        }
        return message
    }
    
    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: UITableView Delegate and Datasource methods
    
    private func numberOfSectionsInTableView(tableView: UITableView) -> Int
    {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return notificArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell = tableView.dequeueReusableCell(withIdentifier: "NotificCellID", for: indexPath) as! NotificTableViewCell
        
        let dictionary = notificArray[indexPath.row] as! NSDictionary
        let process = String(format: "%@", dictionary.value(forKey: "processTag") as! CVarArg)
        let unread = String(format: "%@", dictionary.value(forKey: "unread") as! CVarArg)
        let firstName = String(format: "%@", dictionary.value(forKey: "firstName") as! CVarArg)
        var groupName = String()
        var teamName = String()
        if let groupLogo = dictionary.value(forKey: "groupLogo") as? String
        {
            let filestring = String(format: "%@%@", kfilePath,groupLogo)
            let fileUrl = NSURL(string: filestring)
            cell.logimage?.imageURL = fileUrl as URL?
            
            groupName = String(format: "%@", dictionary.value(forKey: "groupName") as! CVarArg)
            
            cell.imgwidth?.constant = 45.0
        }
        else
        {
            let filestring = String(format: "%@%@", kfilePath,commonmethodClass.retrieveteamlogo())
            let fileUrl = NSURL(string: filestring)
            cell.logimage?.imageURL = fileUrl as URL?
            
            teamName = String(format: "%@", commonmethodClass.retrieveteamdomain())
            
            cell.imgwidth?.constant = 45.0
        }
        
        let message = getmsg(process: process, firstName: firstName, groupName: groupName, teamName: teamName)
        
        cell.msglbl?.attributedText = commonmethodClass.createAttributedString(fullString: message, fullStringColor: blackColor, subString: firstName, subStringColor: blueColor, fullfont: UIFont (name: LatoRegular, size: (cell.msglbl?.font.pointSize)!)!, subfont: UIFont (name: LatoBold, size: (cell.msglbl?.font.pointSize)!)!)
        
        var height = commonmethodClass.dynamicHeight(width: screenWidth-(cell.imgwidth?.constant)!-20.0, font: (cell.msglbl?.font)!, string: message)
        height = ceil(height)
        height = height + 5.0
        
        cell.msgheight?.constant = height
        
        if unread == "1"
        {
            cell.backgroundColor = UIColor(red: 252.0/255.0, green: 246.0/255.0, blue: 175.0/255.0, alpha: 1.0)
        }
        else
        {
            cell.backgroundColor = UIColor.white
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat
    {
        let dictionary = notificArray[indexPath.row] as! NSDictionary
        let process = String(format: "%@", dictionary.value(forKey: "processTag") as! CVarArg)
        let firstName = String(format: "%@", dictionary.value(forKey: "firstName") as! CVarArg)
        var groupName = String()
        var teamName = String()
        var msgwidth = CGFloat()
        if (dictionary.value(forKey: "groupLogo") as? String) != nil
        {
            groupName = String(format: "%@", dictionary.value(forKey: "groupName") as! CVarArg)
            msgwidth = 45.0
        }
        else
        {
            teamName = String(format: "%@", commonmethodClass.retrieveteamdomain())
            msgwidth = 45.0
        }
        
        let message = getmsg(process: process, firstName: firstName, groupName: groupName, teamName: teamName)
        
        var height = commonmethodClass.dynamicHeight(width: screenWidth-msgwidth-20.0, font: UIFont (name: LatoRegular, size: 15.0)!, string: message)
        height = ceil(height)
        height = height + 25.0
        
//        if (dictionary.value(forKey: "groupLogo") as? String) != nil
//        {
//            if height < 55.0
//            {
//                height = 55.0
//            }
//        }
        
        if height < 55.0
        {
            height = 55.0
        }
        
        return height
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        tableView.deselectRow(at: indexPath, animated: true)

        let dictionary = notificArray[indexPath.row] as! NSDictionary
        let process = String(format: "%@", dictionary.value(forKey: "processTag") as! CVarArg)
        
        if process == "groupCreate"
        {
            self.title = ""
            
            let storyBoard = UIStoryboard(name: "Main", bundle: nil)
            let groupdetailsViewObj = storyBoard.instantiateViewController(withIdentifier: "GroupDetailsInfoViewID") as? GroupDetailsInfoViewController
            groupdetailsViewObj?.groupid = String(format: "%@", dictionary.value(forKey: "groupId") as! CVarArg)
            navigation().pushViewController(groupdetailsViewObj!, animated: true)
        }
        else if process == "taskAdd" || process == "myTaskAdd"
        {
            self.title = ""
            
            let bucketdetailObj = self.storyboard?.instantiateViewController(withIdentifier: "BucketDetailViewID") as? BucketDetailViewController
            bucketdetailObj?.taskId = String(format: "%@", dictionary.value(forKey: "taskId") as! CVarArg)
            self.navigationController?.pushViewController(bucketdetailObj!, animated: true)
        }
        else if process == "queueAdd"
        {
            self.title = ""
            
            let queuedetailObj = self.storyboard?.instantiateViewController(withIdentifier: "QueueDetailViewID") as? QueueDetailViewController
            queuedetailObj?.taskId = String(format: "%@", dictionary.value(forKey: "taskId") as! CVarArg)
            self.navigationController?.pushViewController(queuedetailObj!, animated: true)
        }
        else if process == "taskOwnDone" || process == "taskAllDone" || process == "taskOneDone"
        {
            let storyBoard = UIStoryboard(name: "Main", bundle: nil)
            let grouptaskdetailObj = storyBoard.instantiateViewController(withIdentifier: "GroupTaskDetailViewID") as? GroupTaskDetailViewController
            grouptaskdetailObj?.taskId = String(format: "%@", dictionary.value(forKey: "taskId") as! CVarArg)
            grouptaskdetailObj?.notificdictionary = dictionary
            navigation().pushViewController(grouptaskdetailObj!, animated: true)
        }
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
}
