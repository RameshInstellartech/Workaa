//
//  ShareView.swift
//  Workaa
//
//  Created by IN1947 on 05/07/17.
//  Copyright © 2017 IN1947. All rights reserved.
//

import UIKit
import CoreData

class ShareView: UIView, UITextViewDelegate
{
    @IBOutlet weak var shareView : UIView!
    @IBOutlet weak var shareTextView : UITextView!
    @IBOutlet weak var shareplaceholderlbl : UILabel!
    @IBOutlet weak var sharebtn : UIButton!
    @IBOutlet weak var shareViewheight: NSLayoutConstraint!
    @IBOutlet weak var shareTextViewheight: NSLayoutConstraint!
    @IBOutlet weak var closebtn : UIButton!
    
    var viewheight : CGFloat!
    var textheight : CGFloat!
    var keyboardheight : CGFloat!
    var groupId : String!
    var chattype : String!
    var chatdetails = NSManagedObject()
    var commonmethodClass = CommonMethodClass()

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */
    
    func loadShareView(groupId : String, chattype : String, chatdetails : NSManagedObject)
    {
        self.groupId = groupId
        self.chattype = chattype
        self.chatdetails = chatdetails
        
        shareView.layer.cornerRadius = 10;
        
        shareTextView.layer.cornerRadius = 5.0
        shareTextView.layer.borderColor = UIColor.lightGray.cgColor
        shareTextView.layer.borderWidth = 0.5
        
        sharebtn.layer.cornerRadius = sharebtn.frame.size.height/2.0
        
        shareView.layer.opacity = 0.5
        shareView.layer.transform = CATransform3DMakeScale(1.3, 1.3, 1.0)
        UIView.animate(withDuration: 0.2, delay: 0.0, options: .curveEaseInOut, animations: {() -> Void in
            self.backgroundColor = UIColor(white: 0.0, alpha: 0.5)
            self.shareView.layer.opacity = 1.0
            self.shareView.layer.transform = CATransform3DMakeScale(1, 1, 1)
        }, completion: { _ in })
        
        viewheight = shareViewheight.constant
        textheight = shareTextViewheight.constant
        
        shareTextView.becomeFirstResponder()
        
        closebtn.setTitle(closeIcon, for: .normal)
        closebtn.contentEdgeInsets = UIEdgeInsets(top: 0, left: 28, bottom: 0, right: 0)
    }
    
    @IBAction func shareaction(sender: UIButton)
    {
        if shareTextView.text.characters.count > 0
        {
            if chattype == "OneToOneChat"
            {
                var msgId = chatdetails.value(forKey: "msgid") as? String
                var cmtid = ""
                
                if let cmtDetails = chatdetails.value(forKey: "commentdetails") as? NSDictionary
                {
                    cmtid = (cmtDetails.value(forKey: "cmtid") as? String)!
                    msgId = (cmtDetails.value(forKey: "cmtid") as? String)!
                }
                
                if (chatdetails.value(forKey: "sharedetails") as? NSDictionary) != nil
                {
                    cmtid = ""
                    msgId = chatdetails.value(forKey: "msgid") as? String
                }
                
                print("cmtid =>\(cmtid)")
                
                SocketIOManager.sharedInstance.shareOneToOneMessage(message: shareTextView.text!, msgId: msgId!, userid: self.groupId) { (messageInfo) -> Void in
                    
                    print("Share messageInfo =>\(messageInfo)")
                    
                    msgId = self.chatdetails.value(forKey: "msgid") as? String
                    
                    if let getreponse = messageInfo.value(forKey: "apiResponse") as? NSDictionary
                    {
                        if let statuscode = getreponse.value(forKey: "status") as? NSInteger
                        {
                            if statuscode==1
                            {
                                if let datareponse = getreponse.value(forKey: "data") as? NSDictionary
                                {
                                    if let shareid = datareponse.value(forKey: "messageId") as? String
                                    {
                                        let userid = self.chatdetails.value(forKey: "userid") as? String
                                        let username = self.chatdetails.value(forKey: "username") as? String
                                        var message = self.chatdetails.value(forKey: "message") as? String
                                        let sharedate = self.chatdetails.value(forKey: "date") as? String
                                        let date = datareponse.value(forKey: "time") as? String
                                        let teamid = self.chatdetails.value(forKey: "teamid") as? String
                                        var imagepath = self.chatdetails.value(forKey: "imagepath") as? String
                                        let imagetitle = self.chatdetails.value(forKey: "imagetitle") as? String
                                        let filesize = self.chatdetails.value(forKey: "filesize") as? String
                                        let filecaption = self.chatdetails.value(forKey: "filecaption") as? String
                                        
                                        print("message =>\(String(describing: message))")
                                        print("imagepath =>\(String(describing: imagepath))")
                                        
                                        var chatdetailsdict : NSDictionary!
                                        
                                        let sharedetails = ["shareid":msgId!, "sharemessage":self.shareTextView.text!, "sharename":username!, "sharedate":sharedate!, "shareuserid":userid!, "shareteamid":teamid!] as [String : Any]
                                        
                                        if let shareDetails = self.chatdetails.value(forKey: "sharedetails") as? NSDictionary
                                        {
                                            print("shareDetails =>\(shareDetails)")
                                            let sharemessage = shareDetails.value(forKey: "sharemessage") as? String
                                            
                                            if sharemessage != ""
                                            {
                                                message = sharemessage
                                                imagepath = ""
                                            }
                                        }
                                        
                                        if let cmtDetails = self.chatdetails.value(forKey: "commentdetails") as? NSDictionary
                                        {
                                            if cmtid == ""
                                            {
                                                chatdetailsdict = ["userid":self.commonmethodClass.retrieveuserid(), "username":self.commonmethodClass.retrieveusername(), "message":message!, "date":date!, "teamid":self.commonmethodClass.retrieveteamid(), "imagepath":imagepath!, "msgid": shareid, "type": "share", "commentdetails":"", "sharedetails":sharedetails, "imagetitle":imagetitle!, "filesize":filesize!, "filecaption":filecaption!, "sendertype":"right", "senderuserid":self.groupId, "starmsg":"0", "flname" : self.commonmethodClass.retrievename()]
                                            }
                                            else
                                            {
                                                chatdetailsdict = ["userid":self.commonmethodClass.retrieveuserid(), "username":self.commonmethodClass.retrieveusername(), "message":message!, "date":date!, "teamid":self.commonmethodClass.retrieveteamid(), "imagepath":imagepath!, "msgid": shareid, "type": "share", "commentdetails":cmtDetails, "sharedetails":sharedetails, "imagetitle":imagetitle!, "filesize":filesize!, "filecaption":filecaption!, "sendertype":"right", "senderuserid":self.groupId, "starmsg":"0", "flname" : self.commonmethodClass.retrievename()]
                                            }
                                        }
                                        else
                                        {
                                            chatdetailsdict = ["userid":self.commonmethodClass.retrieveuserid(), "username":self.commonmethodClass.retrieveusername(), "message":message!, "date":date!, "teamid":self.commonmethodClass.retrieveteamid(), "imagepath":imagepath!, "msgid": shareid, "type": "share", "commentdetails":"", "sharedetails":sharedetails, "imagetitle":imagetitle!, "filesize":filesize!, "filecaption":filecaption!, "sendertype":"right", "senderuserid":self.groupId, "starmsg":"0", "flname" : self.commonmethodClass.retrievename()]
                                        }
                                        
                                        appDelegate.saveOneToOneChatDetails(chatdetails: chatdetailsdict)
                                        
                                        for aviewcontroller : UIViewController in navigation().viewControllers
                                        {
                                            if let directView = aviewcontroller as? OneToOneChatViewController
                                            {
                                                directView.scrollToBottom(animated: true)
                                                break
                                            }
                                        }
                                        
                                        self.closeaction(sender: UIButton())
                                    }
                                }
                            }
                            else
                            {
                                print("MSG ERROR")
                            }
                        }
                    }
                }
            }
            else if chattype == "CafeChat"
            {
                var msgId = chatdetails.value(forKey: "msgid") as? String
                var cmtid = ""
                
                if let cmtDetails = chatdetails.value(forKey: "commentdetails") as? NSDictionary
                {
                    cmtid = (cmtDetails.value(forKey: "cmtid") as? String)!
                    msgId = (cmtDetails.value(forKey: "cmtid") as? String)!
                }
                
                if (chatdetails.value(forKey: "sharedetails") as? NSDictionary) != nil
                {
                    cmtid = ""
                    msgId = chatdetails.value(forKey: "msgid") as? String
                }
                
                print("cmtid =>\(cmtid)")
                
                SocketIOManager.sharedInstance.shareCafeMessage(message: shareTextView.text!, msgId: msgId!) { (messageInfo) -> Void in
                    
                    print("Share messageInfo =>\(messageInfo)")
                    
                    msgId = self.chatdetails.value(forKey: "msgid") as? String
                    
                    if let getreponse = messageInfo.value(forKey: "apiResponse") as? NSDictionary
                    {
                        if let statuscode = getreponse.value(forKey: "status") as? NSInteger
                        {
                            if statuscode==1
                            {
                                if let datareponse = getreponse.value(forKey: "data") as? NSDictionary
                                {
                                    if let shareid = datareponse.value(forKey: "messageId") as? String
                                    {
                                        let userid = self.chatdetails.value(forKey: "userid") as? String
                                        let username = self.chatdetails.value(forKey: "username") as? String
                                        var message = self.chatdetails.value(forKey: "message") as? String
                                        let sharedate = self.chatdetails.value(forKey: "date") as? String
                                        let date = datareponse.value(forKey: "time") as? String
                                        let teamid = self.chatdetails.value(forKey: "teamid") as? String
                                        var imagepath = self.chatdetails.value(forKey: "imagepath") as? String
                                        let imagetitle = self.chatdetails.value(forKey: "imagetitle") as? String
                                        let filesize = self.chatdetails.value(forKey: "filesize") as? String
                                        let filecaption = self.chatdetails.value(forKey: "filecaption") as? String
                                        
                                        print("message =>\(String(describing: message))")
                                        print("imagepath =>\(String(describing: imagepath))")
                                        
                                        var chatdetailsdict : NSDictionary!
                                        
                                        let sharedetails = ["shareid":msgId!, "sharemessage":self.shareTextView.text!, "sharename":username!, "sharedate":sharedate!, "shareuserid":userid!, "shareteamid":teamid!] as [String : Any]
                                        
                                        if let shareDetails = self.chatdetails.value(forKey: "sharedetails") as? NSDictionary
                                        {
                                            print("shareDetails =>\(shareDetails)")
                                            let sharemessage = shareDetails.value(forKey: "sharemessage") as? String
                                            
                                            if sharemessage != ""
                                            {
                                                message = sharemessage
                                                imagepath = ""
                                            }
                                        }
                                        
                                        if let cmtDetails = self.chatdetails.value(forKey: "commentdetails") as? NSDictionary
                                        {
                                            if cmtid == ""
                                            {
                                                chatdetailsdict = ["userid":self.commonmethodClass.retrieveuserid(), "username":self.commonmethodClass.retrieveusername(), "message":message!, "date":date!, "teamid":self.commonmethodClass.retrieveteamid(), "imagepath":imagepath!, "msgid": shareid, "type": "Share", "commentdetails":"", "sharedetails":sharedetails, "imagetitle":imagetitle!, "filesize":filesize!, "filecaption":filecaption!, "starmsg":"0", "flname" : self.commonmethodClass.retrievename()]
                                            }
                                            else
                                            {
                                                let commentdetails = cmtDetails.mutableCopy() as? NSMutableDictionary
                                                commentdetails?.setValue(self.commonmethodClass.retrieveuserid(), forKey: "senderuserid")
                                                
                                                chatdetailsdict = ["userid":self.commonmethodClass.retrieveuserid(), "username":self.commonmethodClass.retrieveusername(), "message":message!, "date":date!, "teamid":self.commonmethodClass.retrieveteamid(), "imagepath":imagepath!, "msgid": shareid, "type": "Share", "commentdetails":commentdetails!, "sharedetails":sharedetails, "imagetitle":imagetitle!, "filesize":filesize!, "filecaption":filecaption!, "starmsg":"0", "flname" : self.commonmethodClass.retrievename()]
                                            }
                                        }
                                        else
                                        {
                                            chatdetailsdict = ["userid":self.commonmethodClass.retrieveuserid(), "username":self.commonmethodClass.retrieveusername(), "message":message!, "date":date!, "teamid":self.commonmethodClass.retrieveteamid(), "imagepath":imagepath!, "msgid": shareid, "type": "Share", "commentdetails":"", "sharedetails":sharedetails, "imagetitle":imagetitle!, "filesize":filesize!, "filecaption":filecaption!, "starmsg":"0", "flname" : self.commonmethodClass.retrievename()]
                                        }
                                        appDelegate.saveCafeChatDetails(chatdetails: chatdetailsdict)
                                        
                                        for aviewcontroller : UIViewController in navigation().viewControllers
                                        {
                                            if let cafeView = aviewcontroller as? CafeViewController
                                            {
                                                cafeView.scrollToBottom(animated: true)
                                                break
                                            }
                                        }
                                        
                                        self.closeaction(sender: UIButton())
                                    }
                                }
                            }
                            else
                            {
                                print("MSG ERROR")
                            }
                        }
                    }
                    //}
                }
            }
            else
            {
                var msgId = chatdetails.value(forKey: "msgid") as? String
                var cmtid = ""
                
                if let cmtDetails = chatdetails.value(forKey: "commentdetails") as? NSDictionary
                {
                    cmtid = (cmtDetails.value(forKey: "cmtid") as? String)!
                    msgId = (cmtDetails.value(forKey: "cmtid") as? String)!
                }
                
                if (chatdetails.value(forKey: "sharedetails") as? NSDictionary) != nil
                {
                    cmtid = ""
                    msgId = chatdetails.value(forKey: "msgid") as? String
                }
                
                print("cmtid =>\(cmtid)")
                
                SocketIOManager.sharedInstance.shareMessage(message: shareTextView.text!, msgId: msgId!, groupid: self.groupId) { (messageInfo) -> Void in
                    
                    print("Share messageInfo =>\(messageInfo)")
                    
                    msgId = self.chatdetails.value(forKey: "msgid") as? String
                    
                    if let getreponse = messageInfo.value(forKey: "apiResponse") as? NSDictionary
                    {
                        if let statuscode = getreponse.value(forKey: "status") as? NSInteger
                        {
                            if statuscode==1
                            {
                                if let datareponse = getreponse.value(forKey: "data") as? NSDictionary
                                {
                                    if let shareid = datareponse.value(forKey: "messageId") as? String
                                    {
                                        let userid = self.chatdetails.value(forKey: "userid") as? String
                                        let username = self.chatdetails.value(forKey: "username") as? String
                                        var message = self.chatdetails.value(forKey: "message") as? String
                                        let sharedate = self.chatdetails.value(forKey: "date") as? String
                                        let date = datareponse.value(forKey: "time") as? String
                                        let teamid = self.chatdetails.value(forKey: "teamid") as? String
                                        let groupid = self.chatdetails.value(forKey: "groupid") as? String
                                        var imagepath = self.chatdetails.value(forKey: "imagepath") as? String
                                        let imagetitle = self.chatdetails.value(forKey: "imagetitle") as? String
                                        let filesize = self.chatdetails.value(forKey: "filesize") as? String
                                        let filecaption = self.chatdetails.value(forKey: "filecaption") as? String
                                        
                                        print("message =>\(String(describing: message))")
                                        //                                    print("imagepath =>\(String(describing: imagepath))")
                                        
                                        var chatdetailsdict : NSDictionary!
                                        
                                        let sharedetails = ["shareid":msgId!, "sharemessage":self.shareTextView.text!, "sharename":username!, "sharedate":sharedate!, "shareuserid":userid!, "sharegroupid":groupid!, "shareteamid":teamid!] as [String : Any]
                                        
                                        if let shareDetails = self.chatdetails.value(forKey: "sharedetails") as? NSDictionary
                                        {
                                            print("shareDetails =>\(shareDetails)")
                                            let sharemessage = shareDetails.value(forKey: "sharemessage") as? String
                                            
                                            if sharemessage != ""
                                            {
                                                message = sharemessage
                                                imagepath = ""
                                            }
                                        }
                                        
                                        if let cmtDetails = self.chatdetails.value(forKey: "commentdetails") as? NSDictionary
                                        {
                                            if cmtid == ""
                                            {
                                                chatdetailsdict = ["userid":self.commonmethodClass.retrieveuserid(), "username":self.commonmethodClass.retrieveusername(), "message":message!, "date":date!, "teamid":self.commonmethodClass.retrieveteamid(), "groupid":self.groupId, "imagepath":imagepath!, "msgid": shareid, "type": "Share", "commentdetails":"", "sharedetails":sharedetails, "imagetitle":imagetitle!, "filesize":filesize!, "filecaption":filecaption!, "starmsg":"0", "flname" : self.commonmethodClass.retrievename()]
                                            }
                                            else
                                            {
                                                let commentdetails = cmtDetails.mutableCopy() as? NSMutableDictionary
                                                commentdetails?.setValue(self.commonmethodClass.retrieveuserid(), forKey: "senderuserid")
                                                
                                                chatdetailsdict = ["userid":self.commonmethodClass.retrieveuserid(), "username":self.commonmethodClass.retrieveusername(), "message":message!, "date":date!, "teamid":self.commonmethodClass.retrieveteamid(), "groupid":self.groupId, "imagepath":imagepath!, "msgid": shareid, "type": "Share", "commentdetails":commentdetails!, "sharedetails":sharedetails, "imagetitle":imagetitle!, "filesize":filesize!, "filecaption":filecaption!, "starmsg":"0", "flname" : self.commonmethodClass.retrievename()]
                                            }
                                        }
                                        else
                                        {
                                            chatdetailsdict = ["userid":self.commonmethodClass.retrieveuserid(), "username":self.commonmethodClass.retrieveusername(), "message":message!, "date":date!, "teamid":self.commonmethodClass.retrieveteamid(), "groupid":self.groupId, "imagepath":imagepath!, "msgid": shareid, "type": "Share", "commentdetails":"", "sharedetails":sharedetails, "imagetitle":imagetitle!, "filesize":filesize!, "filecaption":filecaption!, "starmsg":"0", "flname" : self.commonmethodClass.retrievename()]
                                        }
                                        
                                        appDelegate.saveChatDetails(chatdetails: chatdetailsdict)
                                        
                                        for aviewcontroller : UIViewController in navigation().viewControllers
                                        {
                                            if let groupView = aviewcontroller as? GroupViewController
                                            {
                                                groupView.scrollToBottom(animated: true)
                                                break
                                            }
                                        }
                                        
                                        self.closeaction(sender: UIButton())
                                    }
                                }
                            }
                            else
                            {
                                print("MSG ERROR")
                            }
                        }
                    }
                }
            }
        }
    }
    
    @IBAction func closeaction(sender: UIButton)
    {
        let currentTransform: CATransform3D = shareView.layer.transform
        
        shareView.layer.opacity = 1.0
        UIView.animate(withDuration: 0.2, delay: 0.0, options: [], animations: {() -> Void in
            self.backgroundColor = UIColor(red: CGFloat(0.0), green: CGFloat(0.0), blue: CGFloat(0.0), alpha: CGFloat(0.0))
            self.shareView.layer.transform = CATransform3DConcat(currentTransform, CATransform3DMakeScale(0.6, 0.6, 1.0))
            self.shareView.layer.opacity = 0.0
        }, completion: {(_ finished: Bool) -> Void in
            for v: UIView in self.subviews {
                v.removeFromSuperview()
            }
            self.removeFromSuperview()
        })
    }
    
    // MARK: - UITextView Delegate
    
    func textViewDidChange(_ textView: UITextView)
    {
        if textView.text.characters.count == 0
        {
            shareplaceholderlbl.isHidden = false
        }
        else
        {
            shareplaceholderlbl.isHidden = true
        }
        
        var totalheight : CGFloat!
        totalheight = screenHeight-keyboardheight-70.0
        
        if totalheight > (textView.contentSize.height+136.0)
        {
            UIView.animate(withDuration: 0.25, delay: 0.0, options: UIViewAnimationOptions.curveEaseOut, animations: {
                
                self.shareTextViewheight.constant = textView.contentSize.height
                self.shareViewheight.constant = self.viewheight + (textView.contentSize.height - self.textheight)
                self.layoutIfNeeded()
                
            }, completion: nil)
        }
    }
}
